# Embed Bot

A Simple Embed Bot - Built on request.

### Env Setup
Create a `.env` file in the root directly.

Copy and paste the following and customize with your data
```
DISCORD_TOKEN=XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
SERVER_INVITE=XXXXXXXXXXXXXXXXX
PREFIX=!
```
